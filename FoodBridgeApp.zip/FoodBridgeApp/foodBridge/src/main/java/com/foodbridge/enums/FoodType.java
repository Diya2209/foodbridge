package com.foodbridge.enums;

public enum FoodType {
	    FRESH, PACKAGED, BEVERAGE, SNACK, DAIRY, GRAINS;
	


}
