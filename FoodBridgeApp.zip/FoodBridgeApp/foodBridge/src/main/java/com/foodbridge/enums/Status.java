package com.foodbridge.enums;

public enum Status {
	AVAILABLE,   
    SCHEDULED,   
    COMPLETED,   
    EXPIRED 

}
