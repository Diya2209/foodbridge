package com.foodbridge.enums;

public enum UserRole {
    VOLUNTEER, DONOR;
}
