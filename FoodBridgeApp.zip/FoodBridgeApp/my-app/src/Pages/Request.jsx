import React from 'react';
import { Link } from 'react-router-dom'; 
import './Card.css';
import Card from './Card';

export default function Request() {
  return (
    <div className="cards-container">
      <Card/>
    </div>
  )
}
